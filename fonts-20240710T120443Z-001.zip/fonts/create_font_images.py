from PIL import Image, ImageDraw, ImageFont
import os


def generate_text_images(text, font_path, output_dir, image_size=(128, 128), font_size=40):
    """
    Generate images of text using a specified TTF font.
    
    :param text: The text to be rendered.
    :param font_path: Path to the TTF font file.
    :param output_dir: Directory where the images will be saved.
    :param image_size: Size of the generated images.
    :param font_size: Size of the font.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    font = ImageFont.truetype(font_path, font_size)
    
    for i, char in enumerate(text):
        image = Image.new('L', image_size, color=255)  # 'L' mode for grayscale
        draw = ImageDraw.Draw(image)
        _, _, text_width, text_height = draw.textbbox((0, 0), text=char, font=font)
        #text_width, text_height = draw.textsize(char, font=font)
        position = ((image_size[0] - text_width) // 2, (image_size[1] - text_height) // 2)
        draw.text(position, char, fill=0, font=font)
        
        # Save the image
        image_path = os.path.join(output_dir, f'{char}_{i}.png')
        image.save(image_path)
        print(f'Saved {image_path}')

# Example usage
text = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
font_path = "learning_curve_regular_ot_tt.ttf"
output_dir = "learning_curve_regular_ot_tt"

generate_text_images(text, font_path, output_dir)
 
